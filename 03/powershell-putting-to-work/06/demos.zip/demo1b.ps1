help about_pipelines
help about_parameters

cls